function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6LZwI9WFqP3":
        Script1();
        break;
      case "66tcI89xbUi":
        Script2();
        break;
      case "5a4hEvxTHWc":
        Script3();
        break;
      case "6WazfYMSNyF":
        Script4();
        break;
      case "6Kr2qh1uKIx":
        Script5();
        break;
      case "6rjBctigXx0":
        Script6();
        break;
      case "5vfPcPWZs4D":
        Script7();
        break;
      case "5jA3x9OYSHL":
        Script8();
        break;
      case "5emEMaLkZIa":
        Script9();
        break;
      case "6cal1bmIX6h":
        Script10();
        break;
      case "65amoRfxIRq":
        Script11();
        break;
      case "67JRmEztM3L":
        Script12();
        break;
      case "6kFTjnBVVNY":
        Script13();
        break;
      case "5vE217TRME8":
        Script14();
        break;
      case "5wUQYiXofps":
        Script15();
        break;
  }
}

function Script1()
{
  window.print();
}

function Script2()
{
  window.print();
}

function Script3()
{
  window.print();
}

function Script4()
{
  window.print();
}

function Script5()
{
  window.print();
}

function Script6()
{
  window.print();
}

function Script7()
{
  window.print();
}

function Script8()
{
  window.print();
}

function Script9()
{
  window.print();
}

function Script10()
{
  window.print();
}

function Script11()
{
  window.print();
}

function Script12()
{
  window.print();
}

function Script13()
{
  window.print();
}

function Script14()
{
  window.print();
}

function Script15()
{
  window.print();
}

